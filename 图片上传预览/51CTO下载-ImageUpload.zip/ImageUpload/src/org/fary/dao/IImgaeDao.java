package org.fary.dao;

import java.util.List;

import org.fary.entity.Image;

public interface IImgaeDao {
	public int add(Image image);

	public List<Image> findAll();
}
