package org.fary.dao.impl;

import java.util.List;

import org.fary.dao.IImgaeDao;
import org.fary.entity.Image;
import org.fary.utils.HibernateSessionFactory;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class ImageDao implements IImgaeDao {
	@Override
	public int add(Image image) {
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		int i = (Integer) session.save(image);

		transaction.commit();
		session.close();
		return i;
	}

	@Override
	public List<Image> findAll() {
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		@SuppressWarnings("unchecked")
		List<Image> list = session.createQuery("from Imgae").list();

		transaction.commit();
		session.close();
		return list;
	}

}
