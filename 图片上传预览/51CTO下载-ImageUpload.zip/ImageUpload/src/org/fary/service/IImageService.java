package org.fary.service;

import java.util.List;

import org.fary.entity.Image;

public interface IImageService {
	public boolean add(Image image);

	public List<Image> findAll();
}
