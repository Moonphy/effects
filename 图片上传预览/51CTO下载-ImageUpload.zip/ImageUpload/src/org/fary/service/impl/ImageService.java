package org.fary.service.impl;

import java.util.List;

import org.fary.dao.IImgaeDao;
import org.fary.entity.Image;
import org.fary.service.IImageService;

public class ImageService implements IImageService {
	private IImgaeDao imageDao;

	public void setImageDao(IImgaeDao imageDao) {
		this.imageDao = imageDao;
	}

	@Override
	public boolean add(Image image) {
		int i = imageDao.add(image);
		if (i > 0) {
			return true;
		}
		return false;
	}

	@Override
	public List<Image> findAll() {
		return imageDao.findAll();
	}
}
