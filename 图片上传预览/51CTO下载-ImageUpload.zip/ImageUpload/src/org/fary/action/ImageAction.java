package org.fary.action;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;
import org.fary.entity.Image;
import org.fary.service.impl.ImageService;
import org.fary.utils.Constants;

import com.opensymphony.xwork2.ActionSupport;

public class ImageAction extends ActionSupport {
	private static final long serialVersionUID = 1L;
	// 这里是固定的写法,文件名子必须跟上一个表单的name属性名字相同，都是image
	private File[] image;
	private String[] imageFileName;

	private Image im;
	private ImageService imageService;

	// 图片集合
	private List<Image> list = null;

	// private static String BASEPATH = "localhost:8080/filedown";

	public Image getIm() {
		return im;
	}

	public void setIm(Image im) {
		this.im = im;
	}

	public void setImageService(ImageService imageService) {
		this.imageService = imageService;
	}

	public File[] getImage() {
		return image;
	}

	public void setImage(File[] image) {
		this.image = image;
	}

	public String[] getImageFileName() {
		return imageFileName;
	}

	public void setImageFileName(String[] imageFileName) {
		this.imageFileName = imageFileName;
	}

	public List<Image> getList() {
		return list;
	}

	public void setList(List<Image> list) {
		this.list = list;
	}

	/**
	 * 构造方法
	 */
	public ImageAction() {
		list = new ArrayList<Image>();
	}

	public String add() throws Exception {
		// 得到当前工程的目录,然后自己再定义下保存的路径
		String realpath = ServletActionContext.getServletContext().getRealPath(
				"/file");
		// 图片的别名
		String basePath = new SimpleDateFormat("yyyyMMddHHmmssSSS")
				.format(new Date());

		if (image != null) {
			File savedir = new File(realpath);
			if (!savedir.exists()) {
				savedir.mkdirs();
			}
			for (int i = 0; i < image.length; i++) {
				File savefile = new File(savedir, basePath + i + "."
						+ getExtensionName(imageFileName[i]));
				FileUtils.copyFile(image[i], savefile);
			}

			im = new Image();
			im.setFirst(Constants.SERVER_ADDRESS + basePath + 0 + "."
					+ getExtensionName(imageFileName[0]));
			im.setSecond(Constants.SERVER_ADDRESS + basePath + 1 + "."
					+ getExtensionName(imageFileName[1]));
			im.setThree(Constants.SERVER_ADDRESS + basePath + 2 + "."
					+ getExtensionName(imageFileName[2]));
			imageService.add(im);
			list.add(im);
		}

		return SUCCESS;
	}

	// 获得图片后缀名
	private String getExtensionName(String filename) {
		if ((filename != null) && (filename.length() > 0)) {
			int dot = filename.lastIndexOf('.');
			if ((dot > -1) && (dot < (filename.length() - 1))) {
				return filename.substring(dot + 1);
			}
		}

		return "";
	}

}