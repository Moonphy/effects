---
title: Features
pagenum: 1
layout: doc
---

#Features

DateBox has a number of kinda cool features, among them:

 - Multiple display and entry modes for dates, times, and durations
   - Android style
   - Full Calendar display
   - Flip (IOS) style
   - Slide style
 - Multiple window modes
   - Popups (2 versions)
   - Dialog (own page)
   - Inline and Slide-Dow
 - Fully localized - 40+ languages pre-configured
 - Fully custiomizable output formats
 - Supports multiple methods of limiting valid date entry
 - Supports entry, exit, creation, selection, change, and more programming hooks
