---
title: Advanced Demos
pagenum: 21
layout: doc
---

# Other Demos

This section features links to other useful demos.  Others will be added as they 
are generated or requested - if you have a good idea, feel free to e-mail the 
maintainer with either the source code, or if you don't know how to make it 
work, just the details of an idea.

 - [Submitting Multiple Date Formats]({{site.basesite}}doc/7-1-formats/)
 - [CustomBox / CustomFlip]({{site.basesite}}doc/7-2-custom/)
 - [Demo Magic (dynamic options)]({{site.basesite}}doc/7-3-demos/)
