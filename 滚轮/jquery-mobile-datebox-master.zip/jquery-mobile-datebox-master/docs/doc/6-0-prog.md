---
title: Extending Datebox
pagenum: 15
layout: doc
---

# Extending DateBox Functionality

The other main reason that people choose DateBox over other options 
available is that it is written by a programmer, for other programmeers.  
There are a plethora of options available to extend it's functionality. 

The next few pages explain how some of these systems work.  For a full 
list of every possibility, take a look at either the advanced demos near 
the end of this documentation, or the full API doumentation.
