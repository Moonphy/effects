---
title: useNewStyle
short: Use the new input display style 
modes: [
]
cats: [ 'display' ]
relat: "display"
layout: api
defval: "--"
dattype: "--"
dyn: "--"
---

**OPTION REMOVED**

New way is much better, and it doesn't require any extra image files.


