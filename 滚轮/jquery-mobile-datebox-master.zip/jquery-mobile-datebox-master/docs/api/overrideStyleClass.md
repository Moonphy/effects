---
title: overrideStyleClass
short: useNewStyle - custom icon class
modes: [
]
cats: [ 'display' ]
relat: "display"
layout: api
defval: "--"
dattype: "--"
dyn: "--"
---

** OPTION REMOVED **

When using {% api_doc useNewStyle %}, override the default icon scheme with a css
class of your own.  Useful if you need more than a single style of datebox icon - otherwise
 just override the css
