---
title: useTodayButton
short: Show button to jump to today
modes: [
	'calbox',
]
cats: [ 'control' ]
relat: "control"
layout: api
defval: "false"
dattype: "Boolean"
dyn: "True"
---

This button will "select" today, but it will not "set" today.  It is for quick navigation.


