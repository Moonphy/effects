---
title: minuteStep
short: Stepper for minutes
modes: [
	'slidebox',
	'timebox',
	'timeflipbox',
]
cats: [ 'limiting' ]
relat: "limiting"
layout: api
defval: "1"
dattype: "Integer"
dyn: "True"
---

Step the minute control by this amount.  Common values are 5, 10, 15, or 30.



