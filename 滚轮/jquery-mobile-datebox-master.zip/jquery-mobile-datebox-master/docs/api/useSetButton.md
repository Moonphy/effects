---
title: useSetButton
short: Show button to set the date
modes: [
	'datebox',
	'flipbox',
	'slidebox',
	'timebox',
	'timeflipbox',
	'durationbox',
]
cats: [ 'control' ]
relat: "control"
layout: api
defval: "true"
dattype: "Boolean"
dyn: "False"
---

This button both sets the date, and closes the control.
