---
title: slen
short: Length of sliders (1/2 of slider)
modes: [
	'slidebox',
]
cats: [ 'control' ]
relat: "control"
layout: api
defval: "{'y': 5, 'm':6, 'd':15, 'h':12, 'i':30}"
dattype: "Object"
dyn: "True"
---

This is the number of elements in the slide roller, divided by 2, add one (the centered element).




