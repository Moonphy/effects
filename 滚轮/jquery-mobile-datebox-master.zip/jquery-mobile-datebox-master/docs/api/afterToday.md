---
title: afterToday
short: Limit dates after today's date
modes: [
	'datebox',
	'calbox',
	'flipbox',
	'slidebox',
]
cats: [ 'limiting' ]
relat: "limiting"
layout: api
defval: "false"
dattype: "Boolean"
dyn: "True"
---

Allows those dates that are after the true value of the client's today
(new Date(); at widget open) to be selected. 
