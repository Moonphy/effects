---
title: calShowWeek
short: Show ISO Week numbers
modes: [
	'calbox',
]
cats: [ 'control' ]
relat: "control"
layout: api
defval: "false"
dattype: "Boolean"
dyn: "True"
---

Add the ISO week number to the calendar display.
