---
title: dialogForce
short: Force use of the jQM Dialog mode
modes: [
	'datebox',
	'timebox',
	'calbox',
	'slidebox',
	'flipbox',
	'timeflipbox',
	'durationbox',
	'durationflipbox',
	'custombox',
	'customflip'
]
cats: [ 'display' ]
relat: "display"
layout: api
defval: "false"
dattype: "Boolean"
dyn: "True"
---

Force datebox to always use jqm builtin dialog mode.
