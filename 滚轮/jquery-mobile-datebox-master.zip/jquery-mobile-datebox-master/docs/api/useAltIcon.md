---
title: useAltIcon
short: useNewStyle - alternate light icon
modes: [
]
cats: [ 'display' ]
relat: "display"
layout: api
defval: "--"
dattype: "--"
dyn: "--"
---

** OPTION REMOVED **

When using {% api_doc useNewStyle %}, use a light colored icon instead of a dark one
