---
title: themeHeader
short: Theme for header
modes: [
	'datebox',
	'timebox',
	'calbox',
	'slidebox',
	'flipbox',
	'timeflipbox',
	'durationbox',
	'durationflipbox',
	'custombox',
	'customflip'
]
cats: [ 'themes' ]
relat: "themes"
layout: api
defval: "a"
dattype: "String"
dyn: "True"
---

For more information on the themeing system, see: [Themeing DateBox]({{site.basesite}}doc/3-1-themes/)
