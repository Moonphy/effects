---
title: themeInput
short: Theme swatch for input elements
modes: [
	'datebox',
	'timebox',
	'durationbox',
	'custombox'
]
cats: [ 'themes' ]
relat: "themes"
layout: api
defval: "a"
dattype: "String"
dyn: "True"
---


For more information on the themeing system, see: [Themeing DateBox]({{site.basesite}}doc/3-1-themes/)
