---
title: calHighToday
short: Highlight today's date
modes: [
	'calbox',
]
cats: [ 'themes' ]
relat: "themes"
layout: api
defval: "true"
dattype: "Boolean"
dyn: "True"
---

Highlight today's date with the theme defined in {% api_doc themeDateToday %}.

For more information on the themeing system, see: [Themeing DateBox]({{site.basesite}}doc/3-1-themes/)


