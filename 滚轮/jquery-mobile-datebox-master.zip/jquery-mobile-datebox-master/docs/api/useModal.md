---
title: useModal
short: Use faded modal background for control
modes: [
	'datebox',
	'timebox',
	'calbox',
	'slidebox',
	'flipbox',
	'timeflipbox',
	'durationbox',
	'durationflipbox',
	'custombox',
	'customflip'
]
cats: [ 'display' ]
relat: "display"
layout: api
defval: "false"
dattype: "Boolean"
dyn: "False"
---

When using datebox popup mode, shade the background and force input to the control
