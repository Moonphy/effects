---
title: customData
short: Data structure for custom modes
modes: [
	'custombox',
	'customflip'
]
cats: [ 'custom' ]
relat: "custom"
layout: api
defval: ""
dattype: "Array"
dyn: "True"
---

The array of data for the CustomBox/CustomFlip control.

See [CustomBox / CustomFlip]({{site.basesite}}doc/7-2-custom/) for a breakdown 
of how to use this option.
