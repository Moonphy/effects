---
title: calWeekHigh
short: Highlight full week on mouseover
modes: [
	'calbox',
]
cats: [ 'themes' ]
relat: "themes"
layout: api
defval: "false"
dattype: "Boolean"
dyn: "True"
---

Desktop operation only, as mobile devices do not generate hover events.
