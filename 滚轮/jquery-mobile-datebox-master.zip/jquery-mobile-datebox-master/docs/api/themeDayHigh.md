---
title: themeDayHigh
short: Theme swatch for highDays
modes: [
	'calbox',
]
cats: [ 'themes' ]
relat: "themes"
layout: api
defval: "b"
dattype: "String"
dyn: "True"
---

For more information on the themeing system, see: [Themeing DateBox]({{site.basesite}}doc/3-1-themes/)

