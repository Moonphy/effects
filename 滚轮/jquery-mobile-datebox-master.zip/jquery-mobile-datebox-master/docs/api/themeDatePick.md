---
title: themeDatePick
short: Theme swatch for choosen date
modes: [
	'calbox',
	'flipbox',
	'slidebox',
	'timeflipbox',
]
cats: [ 'themes' ]
relat: "themes"
layout: api
defval: "b"
dattype: "String"
dyn: "True"
---

For more information on the themeing system, see: [Themeing DateBox]({{site.basesite}}doc/3-1-themes/)

