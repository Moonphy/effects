---
title: maxYear
short: Maximum allowed year
modes: [
	'datebox',
	'flipbox',
	'slidebox',
]
cats: [ 'limiting' ]
relat: "limiting"
layout: api
defval: "false"
dattype: "Integer"
dyn: "True"
---

Do not allow years beyond this one to be selected.


