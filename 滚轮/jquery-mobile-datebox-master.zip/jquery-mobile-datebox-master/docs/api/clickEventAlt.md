---
title: clickEventAlt
short: Listener event for all closing buttons in control
modes: [
	'datebox',
	'timebox',
	'calbox',
	'slidebox',
	'flipbox',
	'timeflipbox',
	'durationbox',
	'durationflipbox'
]
cats: [ 'display' ]
relat: "display"
layout: api
defval: "click"
dattype: "String"
dyn: "False"
---

Listener event for all close-action buttons in the control
