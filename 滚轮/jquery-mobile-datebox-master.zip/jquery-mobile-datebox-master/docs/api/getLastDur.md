---
title: getLastDur
short: Get the last set duration
modes: [
]
cats: [ 'public' ]
relat: "public"
layout: func
rettype: "Integer"
---

Get the last set duration in a durationbox or durationflipbox.


{% highlight js %}
$(input).datebox('getLastDur');
{% endhighlight %}

