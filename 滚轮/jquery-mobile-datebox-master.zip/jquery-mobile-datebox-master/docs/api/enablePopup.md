---
title: enablePopup
short: Use jQM builtin popups
modes: [
	'datebox',
	'timebox',
	'calbox',
	'slidebox',
	'flipbox',
	'timeflipbox',
	'durationbox',
	'durationflipbox',
	'custombox',
	'customflip'
]
cats: [ 'display' ]
relat: "display"
layout: api
defval: "false"
dattype: "Boolean"
dyn: "True"
---

Enable the use of jqm builtin popup mode rather than the datebox native one


