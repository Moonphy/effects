---
title: maxHour
short: Maximum allowed hour
modes: [
	'timebox',
	'timeflipbox',
]
cats: [ 'limiting' ]
relat: "limiting"
layout: api
defval: "false"
dattype: "Integer"
dyn: "True"
---

Allow only hours before this to be selected.


