---
title: centerHoriz
short: Center Horizonitally
modes: [
	'datebox',
	'timebox',
	'calbox',
	'slidebox',
	'flipbox',
	'timeflipbox',
	'durationbox',
	'durationflipbox',
	'custombox',
	'customflip'
]
cats: [ 'display' ]
relat: "display"
layout: api
defval: "false"
dattype: "Boolean"
dyn: "True"
---

When using datebox popup mode, force the control to center horizontally in the window rather than over the input element
