---
title: calWeekModeDay
short: Weekday to select for calWeekMode
modes: [
	'calbox',
]
cats: [ 'control' ]
relat: "control"
layout: api
defval: "1"
dattype: "Integer"
dyn: "True"
---

When using {% api_doc calWeekMode %}, this is the day to select.  Number is zero 
based. (0=Sunday ... 6=Saturday)
