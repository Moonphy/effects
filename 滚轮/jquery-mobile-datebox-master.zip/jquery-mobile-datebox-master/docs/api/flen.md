---
title: flen
short: Height of rollers
modes: [
	'flipbox',
	'timeflipbox',
]
cats: [ 'control' ]
relat: "control"
layout: api
defval: "{'y': 15, 'm':12, 'd':15, 'h':12, 'i':15, 'a':3}"
dattype: "Object"
dyn: "True"
---

This is the number of elements in the flip roller, divided by 2, add one (the centered element).



