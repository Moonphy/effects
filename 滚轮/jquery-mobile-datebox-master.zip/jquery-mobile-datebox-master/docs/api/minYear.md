---
title: minYear
short: Minimum allowed year
modes: [
	'datebox',
	'flipbox',
	'slidebox',
]
cats: [ 'limiting' ]
relat: "limiting"
layout: api
defval: "false"
dattype: "Integer"
dyn: "True"
---

Limit year select to years before this value.


