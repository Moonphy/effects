---
title: calShowDateList
short: Show Special Date List Picker
modes: [
	'calbox',
]
cats: [ 'limiting' ]
relat: "limiting"
layout: api
defval: "false"
dattype: "Boolean"
dyn: "True"
---

When used with {% api_doc calDateList %}, this will show a quick pick list at
the bottom of the calendar control to quickly jump to a "special" date.

