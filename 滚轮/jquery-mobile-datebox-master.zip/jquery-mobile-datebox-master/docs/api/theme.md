---
title: theme
short: Base theme for control
modes: [
	'datebox',
	'timebox',
	'calbox',
	'slidebox',
	'flipbox',
	'timeflipbox',
	'durationbox',
	'durationflipbox',
	'custombox',
	'customflip'
]
cats: [ 'themes' ]
relat: "themes"
layout: api
defval: "false"
dattype: "Boolean"
dyn: "True"
---

For more information on the themeing system, see: [Themeing DateBox]({{site.basesite}}doc/3-1-themes/)

