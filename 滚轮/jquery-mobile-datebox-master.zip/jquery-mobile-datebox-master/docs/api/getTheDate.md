---
title: getTheDate
short: Return the current date object
modes: [
]
cats: [ 'public' ]
relat: "public"
layout: func
rettype: "JavaScript Date() Object"
---

Return the current date object for any date mode.

{% highlight js %}
$(input).datebox('getTheDate');
{% endhighlight %}
