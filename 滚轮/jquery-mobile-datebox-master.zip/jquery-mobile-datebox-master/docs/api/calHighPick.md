---
title: calHighPick
short: Highlight choosen date
modes: [
	'calbox',
]
cats: [ 'themes' ]
relat: "themes"
layout: api
defval: "true"
dattype: "Boolean"
dyn: "True"
---

Highlight choosen date with the theme defined in {% api_doc themeDatePick %}.

For more information on the themeing system, see: [Themeing DateBox]({{site.basesite}}doc/3-1-themes/)


