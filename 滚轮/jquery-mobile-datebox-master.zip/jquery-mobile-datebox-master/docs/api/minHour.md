---
title: minHour
short: Minimum allowed hour
modes: [
	'timebox',
	'timeflipbox',
]
cats: [ 'limiting' ]
relat: "limiting"
layout: api
defval: "false"
dattype: "Integer"
dyn: "True"
---

Do not allow hours before this hour to be selected.


