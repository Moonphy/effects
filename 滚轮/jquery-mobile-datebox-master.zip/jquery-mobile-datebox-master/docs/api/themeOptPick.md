---
title: themeOptPick
short: Theme for highlighted option (customflip)
modes: [
	'customflip'
]
cats: [ 'themes' ]
relat: "themes"
layout: api
defval: "a"
dattype: "String"
dyn: "True"
---

For more information on the themeing system, see: [Themeing DateBox]({{site.basesite}}doc/3-1-themes/)

For more information on Custom, see: [CustomBox/CustomFlip]({{site.basesite}}doc/7-2-custom/)
