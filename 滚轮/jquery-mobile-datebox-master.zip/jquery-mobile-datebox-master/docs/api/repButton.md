---
title: repButton
short: When button held, continue counting
modes: [
	'datebox',
	'timebox',
	'durationbox'
]
cats: [ 'control' ]
relat: "control"
layout: api
defval: "true"
dattype: "Boolean"
dyn: "True"
---

When a +/- button is held down by the user, continue countig - with acceleration.


