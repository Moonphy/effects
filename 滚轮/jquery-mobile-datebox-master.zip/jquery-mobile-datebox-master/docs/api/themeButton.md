---
title: themeButton
short: Theme swatch for +/- Buttons
modes: [
	'datebox',
	'timebox',
	'durationbox',
	'custombox'
]
cats: [ 'themes' ]
relat: "themes"
layout: api
defval: "a"
dattype: "String"
dyn: "True"
---

For more information on the themeing system, see: [Themeing DateBox]({{site.basesite}}doc/3-1-themes/)

