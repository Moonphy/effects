---
title: transition
short: Transition for display
modes: [
	'datebox',
	'timebox',
	'calbox',
	'slidebox',
	'flipbox',
	'timeflipbox',
	'durationbox',
	'durationflipbox',
	'custombox',
	'customflip'
]
cats: [ 'display' ]
relat: "display"
layout: api
defval: "pop"
dattype: "String"
dyn: "False"
---

Transition to use on datebox popup, jqm popup, and dialog display modes
