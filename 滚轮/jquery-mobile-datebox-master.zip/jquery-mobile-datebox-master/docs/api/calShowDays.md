---
title: calShowDays
short: Show Day Labels
modes: [
	'calbox',
]
cats: [ 'control' ]
relat: "control"
layout: api
defval: "true"
dattype: "Boolean"
dyn: "True"
---

Add the short names of the days of the week to the calendar display.


