DateBox Test Files
==================

* dev.php : My testbed - has all the defaults, linked agains uncompressed js
* lang.php : A quick i18n test tool.  Bombs if any of the files are bad.
* ns.php : Uses jQM namespacing, makes sure datebox still works.
