jQuery-Mobile-DateBox
=====================

This folder contains a relativly recent copy of yui-compressor.

It is used in the build process.  Please see the included LICENSE
