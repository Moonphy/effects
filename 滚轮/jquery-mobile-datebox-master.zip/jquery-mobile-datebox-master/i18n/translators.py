#!/usr/bin/python

trans = {
	'af': 'Jan Verhaeghe <crowdin>',   #Afrikaans
	'ar': 'Michael de Lara <mykel1829@yahoo.com>, Houshmand Rastin <crowdin>',  #Arabic
	'bg': 'How Bizarre <how@errazib.com>',  #Bulgarian
	#'ca': #Catalan
	#'cs': #Czech
	'da': 'Jnyrup <crowdin>', #Danish
	'de': 'Chris P. Vigelius <me@cv.gd>, Pascal Hofmann <crowdin>', #German
	'el': 'Giannis Kosmas <kosmasgiannis@gmail.com>', #Greek
	'en': 'J.T.Sage <jtsage@gmail.com>',
	'en_US': 'J.T.Sage <jtsage@gmail.com>',
	'es-ES': 'Rafael Carballo Cerqueira, Josh W <crowdin> Gui_gofu <crowdin>', #Spanish
	'fi': 'Ville Salonen <ville.salonen@iki.fi>', #Finnish
	'fr': 'Jan Verhaeghe <crowdin>, lgoncalves <crowdin>', #French
	'he': 'Kobi Hikri <kobi.hikri@gmail.com>', #Hebrew
	'hr': 'Marko <ma3ko0@gmail.com>', #Croation
	'hu': 'titititatatatititi <crowdin>', #Hungarian
	'id': 'Sutisna <crowdin>, Yashdiq Lubis <crowdin>', #Indonesion
	'it': 'Giuseppe Petagine <giuseppe.petagine@virgilio.it>, mauretto <crowdin>', #Italian
	'ja': 'Moon Dial, pokutuna popopo <crowdin>', #Japanese
	'ko': 'mooyoul <crowdin>', #Korean
	'lt': 'Tadas Subonis <tadas.subonis@affecto.com>', #Lituanian
	'nl': 'G. Hengeveld <info@ghengeveld.nl>, Arjan ven Bentem <crowdin>', #Dutch
	'nl-BE': 'Jan Verhaeghe <crowdin>', #Dutch, Belgium
	'no': 'Robin Heggelund Hansen <skinneyz89@gmail.com>', #Norwegian
	'pt-BR': 'Rodrigo Vieira <rodrigovieira1994@gmail.com>, Marcelo Dezem <crowdin>', #Portugese, Brazil
	'pt-PT': 'Marcelo Dezem <crowdin>, Sergio Martins <crowdin>', #Portugese
	'pl': 'Zbigniew Motyka <zbigniew@motyka.net.pl>', #Polish
	#'ro': #Romainian
	'ru': 'Alexander Zolotko <azolotko@gmail.com>', #Russian
	#'sr': #Serbian 
	'sl': 'Blaz Kristan <blaz@kristan-sp.si>', #Slovenian
	'sv-SE': 'Henrik Ekselius <henrik@xelius.net>', #swedish
	'th': 'tiratat.patana-anake <tiratat.patana-anake@accenture.com>, bu_echo <crowdin>', #Thai
	'tr': 'weli.cengiz <crowdin>, zlkklm <crowdin>', #Turkish
	'uk': 'Alexander Zolotko <azolotko@gmail.com>', #Ukranian
	#'vi': #Vietnamese
	'zh-TW': 'Ethan Chen <ethan42411@gmail.com>, michelle4233536 <crowdin>', #Chinese - Trad
	'zh-CN': 'ChiElvis <elvis311@msn.com>, Josh W <crowdin>, ulone <crowdin>, Fred Qiao <crowdin>, Loexe_one <crowdin>, share123 <crowdin>, pokutuna popopo <crowdin>', #Chinese - Simp
}
