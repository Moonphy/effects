var gamedata = {
	imageFiles : [ 
		"library/titlescreen.png", 
		"library/titleback.png", 
		"library/alienbomb.png", 
		"library/aliensheet.png", 
		"library/explosion.png", 
		"library/playersheet.png", 
		"library/playpause.png", 
		"library/gamebackdrop.gif",
		"library/bonusitems.gif",
		"library/lasers.gif",
		"library/splash.png"
	],
	audioFiles : [ 
	]
};
